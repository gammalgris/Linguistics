/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2022  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id: 0e580be6d7b7621945239021a371c00f16d08155 $
 */

package jmul.math.numbers.notations;


import jmul.math.operations.Operation;
import jmul.math.numbers.Number;


/**
 * This interface describes a function for generating a string representation for a number. Number can be
 * represented in various ways and there exists several different notations.
 *
 * @author Kristian Kutin
 */
public interface NotationFunction extends Operation {

    /**
     * Translates the specified number into a string notation.
     *
     * @param number
     *        a number
     * @param decimalSeparator
     *        a decimal separator
     *
     * @return a string representation
     */
    String toString(Number number, char decimalSeparator);

}
