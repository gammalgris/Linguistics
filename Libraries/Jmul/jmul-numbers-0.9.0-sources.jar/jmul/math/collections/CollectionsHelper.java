/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2025  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id$
 */

package jmul.math.collections;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jmul.math.fractions.Fraction;
import jmul.math.numbers.Number;
import static jmul.math.numbers.NumberHelper.createNumber;
import jmul.math.operations.implementations.ParameterCheckHelper;


/**
 * A utility class for collections.<br>
 * <br>
 * <i>Note:<br>
 * Instantiating large sets or sequences is not efficient. New helper ,ethods and cosntructors will
 * be required if performance is an issue.</i>
 *
 * @author Kristian Kutin
 */
public final class CollectionsHelper {

    /**
     * The default constructor.
     */
    private CollectionsHelper() {

        throw new IllegalArgumentException();
    }

    /**
     * Creates a new number set according to the specified parameters.
     *
     * @param base
     *        a number base
     * @param elementStrings
     *        all element string
     *
     * @return a number set
     */
    public static Set<Number> createNumberSet(int base, String... elementStrings) {

        Number[] elements = new Number[elementStrings.length];

        for (int a = 0; a < elementStrings.length; a++) {

            Number element = createNumber(base, elementStrings[a]);
            elements[a] = element;
        }

        return new SetImpl<>(base, elements);
    }

    /**
     * Creates a new number set according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a number set
     */
    public static Set<Number> createNumberSet(Number... elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (elements.length == 0) {

            throw new IllegalArgumentException("No elements (empty array) were specified!");
        }

        int base = elements[0].base();

        return new SetImpl<>(base, elements);
    }

    /**
     * Creates a new number set according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a number set
     */
    public static Set<Number> createNumberSet(Collection<Number> elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (elements.size() == 0) {

            throw new IllegalArgumentException("No elements (empty list) were specified!");
        }

        int base = elements.iterator().next().base();

        Number[] array = new Number[] { };
        return new SetImpl<>(base, elements.toArray(array));
    }

    /**
     * Creates a new number sequence according to the specified parameters.
     *
     * @param base
     *        a number base
     * @param elementStrings
     *        all elements as strings
     *
     * @return a number sequence
     */
    public static Sequence<Number> createNumberSequence(int base, String... elementStrings) {

        ParameterCheckHelper.checkNumberBase(base);

        if (elementStrings == null) {

            throw new IllegalArgumentException("No element strings (null) were specified!");
        }

        if (elementStrings.length == 0) {

            throw new IllegalArgumentException("No element strings (empty array) were specified!");
        }

        Number[] elements = new Number[elementStrings.length];

        for (int a = 0; a < elementStrings.length; a++) {

            Number element = createNumber(base, elementStrings[a]);
            elements[a] = element;
        }

        return new SequenceImpl<>(base, elements);
    }

    /**
     * Creates a new number sequence according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a number sequence
     */
    public static Sequence<Number> createNumberSequence(Number... elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (elements.length == 0) {

            throw new IllegalArgumentException("No elements (empty array) were specified!");
        }

        int base = elements[0].base();

        return new SequenceImpl<>(base, elements);
    }

    /**
     * Creates a new number sequence according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a number sequence
     */
    public static Sequence<Number> createNumberSequence(Collection<Number> elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (elements.size() == 0) {

            throw new IllegalArgumentException("No elements (empty list) were specified!");
        }

        int base = elements.iterator().next().base();

        Number[] array = new Number[] { };
        return new SequenceImpl<>(base, elements.toArray(array));
    }

    /**
     * Creates a new number sequence according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a number sequence
     */
    public static Sequence<Number> createNumberSequence(Iterable<Number> elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (!elements.iterator().hasNext()) {

            throw new IllegalArgumentException("No elements (empty iterable data container) were specified!");
        }

        return createNumberSequence(rewrapData(elements));
    }

    /**
     * This method rewraps data.
     *
     * @param elements
     *        an iterable data container
     *
     * @return a collection of data
     */
    private static Collection<Number> rewrapData(Iterable<Number> elements) {

        List<Number> list = new ArrayList<>();

        for (Number element : elements) {

            list.add(element);
        }

        return list;
    }

    /**
     * Creates a new fraction sequence according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a fraction sequence
     */
    public static Sequence<Fraction> createFractionSequence(Fraction... elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (elements.length == 0) {

            throw new IllegalArgumentException("No elements (empty array) were specified!");
        }

        int base = elements[0].base();

        return new SequenceImpl<>(base, elements);
    }

    /**
     * Creates a new fraction sequence according to the specified parameters.
     *
     * @param elements
     *        all elements
     *
     * @return a fraction sequence
     */
    public static Sequence<Fraction> createFractionSequence(Collection<Fraction> elements) {

        if (elements == null) {

            throw new IllegalArgumentException("No elements (null) were specified!");
        }

        if (elements.size() == 0) {

            throw new IllegalArgumentException("No elements (empty list) were specified!");
        }

        int base = elements.iterator().next().base();

        Fraction[] array = new Fraction[] { };
        return new SequenceImpl<>(base, elements.toArray(array));
    }

}
