/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2026  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id$
 */

package jmul.math.functions;


import jmul.math.operations.processing.ProcessingDetails;
import jmul.math.numbers.Number;


/**
 * An implementation of a chained function.
 *
 * @author Kristian Kutin
 */
public class ChainedFunctionImpl extends FunctionBaseImpl implements ChainedFunction {

    /**
     * An outer function.
     */
    private final Function outerFunction;

    /**
     * An inner function.
     */
    private final Function innerFunction;

    /**
     * Creates a new instance according to the specified parameters.
     *
     * @param outerFunction
     *        an outer function
     * @param innerFunction
     *        an inner function
     */
    public ChainedFunctionImpl(Function outerFunction, Function innerFunction) {

        super(extractBase(outerFunction, innerFunction));

        this.innerFunction = innerFunction;
        this.outerFunction = outerFunction;
    }

    /**
     * Checks the specified parameters and tries to extract a number base.
     *
     * @param outerFunction
     *        an outer function
     * @param innerFunction
     *        an inner function
     *
     * @return a number base
     */
    private static int extractBase(Function outerFunction, Function innerFunction) {

        if (outerFunction == null) {

            throw new IllegalArgumentException("No outer function (null) was specified!");
        }

        if (innerFunction == null) {

            throw new IllegalArgumentException("No inner function (null) was specified!");
        }

        return outerFunction.base();
    }

    /**
     * The inner function.
     *
     * @return a function
     */
    @Override
    public Function innerFunction() {

        return innerFunction;
    }

    /**
     * The outer function.
     *
     * @return a function
     */
    @Override
    public Function outerFunction() {

        return outerFunction;
    }

    /**
     * Calculate the function value for x.
     *
     * @param processingDetails
     *        additonal processing details
     * @param x
     *        the input value
     *
     * @return f(x)
     */
    @Override
    public Number calculate(ProcessingDetails processingDetails, Number x) {

        // f(x) = g(h(x))

        Number result = innerFunction.calculate(processingDetails, x);
        result = outerFunction.calculate(processingDetails, result);

        return result;
    }

    /**
     * Returns the derivative function for this function.
     *
     * @return a derivative function
     */
    @Override
    public Function derivativeFunction() {

        // f(x) = g(h(x))
        // f'(x) = g'(h(x)) * h'(x)

        Function outerDerivative = outerFunction.derivativeFunction();
        Function innerDerivative = innerFunction.derivativeFunction();

        Function chainedFunction = new ChainedFunctionImpl(outerDerivative, innerFunction);

        Function productFunction = new ProductFunctionImpl(chainedFunction, innerDerivative);

        return productFunction;
    }

    /**
     * Returns a string representation for this function.
     *
     * @return a string representation
     */
    @Override
    public String toString() {

        String inner = innerFunction.toString();
        String outer = outerFunction.toString();

        String both = outer.replace("x", "(" + inner + ")");

        return both;
    }

}
