/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2026  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id$
 */

package jmul.math.functions;


import jmul.math.numbers.Number;
import jmul.math.operations.processing.ProcessingDetails;


/**
 * An implementation of a sum function.
 *
 * @author Kristian Kutin
 */
public class SumFunctionImpl extends FunctionBaseImpl implements SumFunction {

    /**
     * The first function.
     */
    private final Function firstFunction;

    /**
     * The second function.
     */
    private final Function secondFunction;

    /**
     * Creates a new instance according to the specified parameters.
     *
     * @param firstFunction
     *        a first function
     * @param secondFunction
     *        a second function
     */
    public SumFunctionImpl(Function firstFunction, Function secondFunction) {

        super(extractBase(firstFunction, secondFunction));

        this.firstFunction = firstFunction;
        this.secondFunction = secondFunction;
    }

    /**
     * Checks the specified parameters and tries to extract a number base.
     *
     * @param firstFunction
     *        a first function
     * @param secondFunction
     *        a second function
     *
     * @return a number base
     */
    private static int extractBase(Function firstFunction, Function secondFunction) {

        if (firstFunction == null) {

            throw new IllegalArgumentException("No first function (null) was specified!");
        }

        if (secondFunction == null) {

            throw new IllegalArgumentException("No second function (null) was specified!");
        }

        return firstFunction.base();
    }

    /**
     * The first function.
     *
     * @return a function
     */
    @Override
    public Function firstFunction() {

        return firstFunction;
    }

    /**
     * The second function.
     *
     * @return a function
     */
    @Override
    public Function secondFunction() {

        return secondFunction;
    }

    /**
     * Calculate the function value for x.
     *
     * @param processingDetails
     *        additonal processing details
     * @param x
     *        the input value
     *
     * @return f(x)
     */
    @Override
    public Number calculate(ProcessingDetails processingDetails, Number x) {

        // f(x) = g(x) + h(x)

        Number result1 = firstFunction.calculate(processingDetails, x);
        Number result2 = secondFunction.calculate(processingDetails, x);

        return result1.add(result2);
    }

    /**
     * Returns the derivative function for this function.
     *
     * @return a derivative function
     */
    @Override
    public Function derivativeFunction() {

        // f(x) = g(x) + h(x)
        // f'(x) = g'(x) + h'(x)

        Function firstDerivative = firstFunction.derivativeFunction();
        Function secondDerivative = secondFunction.derivativeFunction();

        return new SumFunctionImpl(firstDerivative, secondDerivative);
    }

    /**
     * Returns a string representation for this function.
     *
     * @return a string representation
     */
    @Override
    public String toString() {

        return String.format("( %s ) + ( %s )", firstFunction, secondFunction);
    }

}
