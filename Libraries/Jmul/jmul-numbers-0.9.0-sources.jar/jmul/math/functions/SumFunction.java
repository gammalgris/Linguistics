/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2026  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id$
 */

package jmul.math.functions;


/**
 * A sum function is a function which consists of two functions which are added.<br>
 * <br>
 * Example of a sum function and the derivative of the sum function:<br>
 * <br>
 * f(x) = g(x) + h(x)<br>
 * <br>
 * f'(x) = g'(x) + h'(x)<br>
 * <br>
 * <i>Note:<br>
 * The derivative of the sum function can be calculated with the sum rule (see
 * <a href="https://en.wikipedia.org/wiki/Differentiation_rules#Differentiation_is_linear">sum rule</a>).</i><br>
 * <br>
 * <i>Note:<br>
 * The name of this function may be misleading. It should indicate that the sum rule is used to determine the
 * derivative function.</i>
 */
public interface SumFunction extends Function {

    /**
     * The first function.
     *
     * @return a function
     */
    Function firstFunction();

    /**
     * The second function.
     *
     * @return a function
     */
    Function secondFunction();

}
