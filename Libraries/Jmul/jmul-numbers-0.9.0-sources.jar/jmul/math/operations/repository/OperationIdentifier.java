/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2022  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id: 4786055cf76d2ff6e467889342b70c7542ce3217 $
 */

package jmul.math.operations.repository;


import jmul.math.operations.OperationClassifier;


/**
 * This interface describes an identifier for functions/ operations/ algorithms.
 *
 * @author Kristian Kutin
 */
public interface OperationIdentifier extends CharSequence {

    /**
     * Returns the operation classifier associated with this function/ operation/ algorithm identifier.
     *
     * @return an operation classifier
     */
    OperationClassifier operationClassifier();

}
