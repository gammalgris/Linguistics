/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2025  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id$
 */

package jmul.math.operations.implementations;


import java.util.ArrayList;
import java.util.List;

import jmul.math.Math;
import jmul.math.collections.Set;
import jmul.math.collections.SetImpl;
import jmul.math.numbers.Number;
import jmul.math.operations.Result;
import jmul.math.operations.UnaryOperation;


/**
 * An implementation of a function that determines the divisors of a number.
 *
 * @author Kristian Kutin
 */
public class DetermineDivisors implements UnaryOperation<Number, Result<Set<Number>>> {

    /**
     * The default constructor.
     */
    public DetermineDivisors() {

        super();
    }

    /**
     * Determines the divisors of the specified number and returns a set with all divisors greater than one.
     *
     * @param operand
     *        a number
     *
     * @return a set of divisors
     */
    @Override
    public Result<Set<Number>> calculate(Number operand) {

        ParameterCheckHelper.checkInteger(operand);

        int base = operand.base();
        Number absoluteOperand = operand.absoluteValue();

        final Number ONE = Math.ONE.value(base);
        final Number TWO = Math.TWO.value(base);

        List<Number> divisors = new ArrayList<>();
        divisors.add(ONE);

        for (Number number = TWO; number.isLesser(absoluteOperand); number = number.inc()) {

            Number doubled = number.doubling();

            if (doubled.isLesserOrEqual(absoluteOperand)) {

                if (absoluteOperand.isMultipleOf(number)) {

                    divisors.add(number);
                }

            } else {

                break;
            }
        }

        if (!absoluteOperand.isOne()) {

            divisors.add(absoluteOperand);
        }

        Set<Number> resultSet = new SetImpl<>(base, divisors);
        return new Result<Set<Number>>(resultSet);
    }

}
