/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2026  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id$
 */

package jmul.math.operations.implementations;


import jmul.math.numbers.Number;
import jmul.math.operations.MixedTernaryOperation;
import jmul.math.operations.Result;
import jmul.math.operations.processing.ProcessingDetails;
import jmul.math.vectors.Vector;


/**
 * This function implementation calculates the length of a vector.
 *
 * @author Kristian Kutin
 */
public class VectorLength implements MixedTernaryOperation<Vector, Number, Result<Number>> {

    /**
     * The default constructor.
     */
    public VectorLength() {

        super();
    }

    /**
     * Calculates the length of the specified vector.
     *
     * @param vector
     *        a vector
     * @param iterations
     *        the number of iterations
     * @param decimalPlaces
     *        the number of decimal places retained after cutting the fraction part
     *
     * @return a number which represents the length of the specified vector.
     */
    @Override
    public Result<Number> calculate(Vector vector, Number iterations, Number decimalPlaces) {

        ParameterCheckHelper.checkParameter(vector);
        ParameterCheckHelper.checkIntegerIgnoreNull(iterations);
        ParameterCheckHelper.checkIntegerIgnoreNull(decimalPlaces);

        Number scalarProduct = vector.scalarProduct(vector);

        ProcessingDetails processingDetails =
            ProcessingDetails.setProcessingDetails(ProcessingDetails.DEFAULT_ALGORITHM, decimalPlaces, iterations);

        Number result = scalarProduct.squareRoot(processingDetails);

        return new Result<Number>(result);
    }

}
