/*
 * SPDX-License-Identifier: GPL-3.0
 *
 *
 * (J)ava (M)iscellaneous (U)tilities (L)ibrary
 *
 * JMUL is a central repository for utilities which are used in my
 * other public and private repositories.
 *
 * Copyright (C) 2022  Kristian Kutin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * e-mail: kristian.kutin@arcor.de
 */

/*
 * This section contains meta informations.
 *
 * $Id: 2bdc2d2ec07593414717f5ff689c925fcf927aa5 $
 */

package jmul.math.operations;


/**
 * This interface describes an equality comparator.
 *
 * @author Kristian Kutin
 *
 * @param <T>
 *        the type of objects to compare
 */
public interface EqualityFunction<T> {

    /**
     * Checks the two specified objects for equality.
     *
     * @param t1
     *        an object
     * @param t2
     *        an object
     *
     * @return <code>true</code> if bothe objects are considered equal, else <code>false</code>
     */
    boolean equals(T t1, T t2);

}
